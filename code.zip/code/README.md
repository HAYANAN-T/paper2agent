# paper2agent (analysis)

Companion code for the article **"The Paper That Talks Back: How Stanford Turned Dead PDFs Into Living AI Scientists."**

Models the key ideas behind Stanford's Paper2Agent (Miao et al., Nature 2026):
why its paper-conversion rate is really a reproducibility measurement, and why
the value of a paper-agent network grows with the square of the agents.

## Quick start
```bash
pip install -r requirements.txt
python -m sim.repro            # reproducibility + network model -> results/repro.json
python viz/make_figures.py     # the charts and diagrams
python viz/make_gif.py         # the paper-to-agent animation
python viz/cover.py            # the cover
```

## Headline results
| Result | Value |
|---|---|
| Conversion if paper shares nothing / data / code+data | 5% / 33% / 86% |
| Modeled overall conversion (good code-sharing corpus) | ~74% (matches the real study) |
| Cross-paper connections at N agents | grows as N^2 |

Real study figures (Miao et al., Nature 2026): 74/100 papers converted, 593/599
tools passed, 91.2% vs 80.3% baseline accuracy, AlphaGenome agent in 45 min / $14.

## License
Code: MIT.

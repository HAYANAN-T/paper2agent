"""
sim.repro - a model of Paper2Agent as a *reproducibility engine*.

The deep insight behind Paper2Agent is easy to miss: to turn a paper into an
agent, the system must actually *re-run the paper's code* in a clean environment
and confirm it produces working tools. That means the conversion success rate is
really a measurement of reproducibility. Stanford reported 74 of 100 papers
converted, and 593 of 599 generated tools passing automated validation.

This module models what determines whether a paper can be "agentified": whether
it shared code, whether that code still runs, and whether the tools it exposes
pass validation. We use it to:

  E1: show how conversion success depends on what a paper actually shares
      (nothing / data only / code+data), anchored to the reproducibility
      literature (86% reproducible with code+data vs 33% with data only).
  E2: model the "paper speed-dating" network - as you agentify more papers, how
      many *cross-paper* connections become possible, and how many plausibly
      yield a novel link like the ADHD/MPHOSPH9 finding.
"""
from __future__ import annotations
import numpy as np
from dataclasses import dataclass


# Reproducibility priors from the literature (see article references):
P_REPRO = {
    "nothing": 0.05,     # no code, no data: almost never reproducible
    "data_only": 0.33,   # data shared, no runnable code
    "code_data": 0.86,   # both shared: mostly reproducible
}


@dataclass
class ReproConfig:
    n_papers: int = 100
    # how the corpus splits across sharing practices
    frac_nothing: float = 0.10
    frac_data_only: float = 0.10
    frac_code_data: float = 0.80
    tool_pass_rate: float = 0.99   # 593/599 tools passed in the real study
    seed: int = 0


def run_conversion(cfg: ReproConfig):
    rng = np.random.default_rng(cfg.seed)
    n = cfg.n_papers
    kinds = (["nothing"] * int(cfg.frac_nothing * n)
             + ["data_only"] * int(cfg.frac_data_only * n)
             + ["code_data"] * int(cfg.frac_code_data * n))
    kinds += ["code_data"] * (n - len(kinds))
    rng.shuffle(kinds)
    converted = np.array([rng.random() < P_REPRO[k] for k in kinds])
    return {
        "kinds": kinds,
        "converted": converted,
        "conversion_rate": float(converted.mean()),
        "by_kind": {k: float(np.mean([c for kk, c in zip(kinds, converted) if kk == k]))
                    for k in P_REPRO},
    }


def network_effect(max_papers=1000, link_prob=0.002, novel_frac=0.1, seed=0):
    """As more papers become agents, cross-paper pairs grow quadratically.

    pairs = C(n,2). A small fraction of pairs share enough structure to connect;
    a fraction of those connections surface a genuinely novel link.
    """
    ns = np.unique(np.round(np.logspace(1, np.log10(max_papers), 30)).astype(int))
    pairs = ns * (ns - 1) / 2
    connections = pairs * link_prob
    novel = connections * novel_frac
    return {"n": ns.tolist(), "pairs": pairs.tolist(),
            "connections": connections.tolist(), "novel": novel.tolist()}


def main():
    import json, pathlib
    ROOT = pathlib.Path(__file__).resolve().parents[1]

    # E1: conversion by sharing practice, averaged over seeds
    rates = {"nothing": [], "data_only": [], "code_data": [], "overall": []}
    for s in range(400):
        r = run_conversion(ReproConfig(seed=s))
        for k in ("nothing", "data_only", "code_data"):
            rates[k].append(r["by_kind"][k])
        rates["overall"].append(r["conversion_rate"])
    e1 = {k: float(np.mean(v)) for k, v in rates.items()}

    # E2: the network effect
    e2 = network_effect()

    out = {"e1": e1, "p_repro": P_REPRO, "e2": e2,
           "real": {"converted": 74, "total": 100, "accuracy": 91.2,
                    "baseline": 80.3, "tools_pass": 593, "tools_total": 599,
                    "alphagenome_acc": 98.7, "alphagenome_baseline": 82.7,
                    "time_min": 45, "cost_usd": 14}}
    (ROOT / "results").mkdir(exist_ok=True)
    json.dump(out, open(ROOT / "results/repro.json", "w"), indent=2)
    print("E1 conversion by sharing practice:")
    for k in ("nothing", "data_only", "code_data"):
        print(f"   {k:11s}: {e1[k]:.0%}")
    print(f"   overall     : {e1['overall']:.0%}  (real study: 74%)")
    print(f"\nE2 at 1,000 agents: {e2['connections'][-1]:,.0f} possible connections, "
          f"~{e2['novel'][-1]:,.0f} plausibly novel")


if __name__ == "__main__":
    main()

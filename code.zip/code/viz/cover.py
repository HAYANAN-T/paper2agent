"""Cover: a PDF morphing into a glowing agent node."""
import sys, pathlib
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
ROOT=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from viz.style import *  # noqa
AIC=GOOD; BLUE=RESTRAINED; PURPLE=MIXED; GOLD=PASSIVE
def main():
    fig=plt.figure(figsize=(8,4.5),facecolor="#F3F6FA")
    fig.text(0.06,0.76,"The paper that",fontsize=28,fontweight="bold",color=INK,va="center")
    fig.text(0.06,0.66,"talks back",fontsize=28,fontweight="bold",color=PURPLE,va="center")
    fig.text(0.06,0.50,"Stanford turned scientific papers into AI agents\nthat answer questions, run their own methods,\nand team up to make discoveries no one published.",
             fontsize=10.5,color=SUB,va="center",linespacing=1.5)
    fig.text(0.06,0.15,"Right: a static paper becoming a living, callable agent, with working\ntools instead of words on a page.",
             fontsize=7.4,color=FAINT,linespacing=1.4)
    ax=fig.add_axes([0.56,0.14,0.4,0.72]); ax.set_xlim(0,10); ax.set_ylim(0,8); ax.axis("off")
    # pdf
    ax.add_patch(FancyBboxPatch((0.4,2.4),2.6,3.4,boxstyle="round,pad=0,rounding_size=0.08",fc="white",ec=RULE,lw=1.4))
    for i in range(8):
        ax.plot([0.9,2.5],[5.2-i*0.36,5.2-i*0.36],color="#C8D0DB",lw=2,solid_capstyle="round")
    # arrow
    ax.add_patch(FancyArrowPatch((3.2,4.1),(5.0,4.1),arrowstyle="-|>",mutation_scale=16,color=FAINT,lw=2))
    # agent node with tool satellites
    ax.add_patch(Circle((7.2,4.1),1.3,fc=PURPLE,alpha=0.9,ec="white",lw=2,zorder=4))
    ax.text(7.2,4.1,"agent",ha="center",va="center",fontsize=11,color="white",fontweight="bold",zorder=5)
    import numpy as np
    for ang in np.linspace(0,2*np.pi,6,endpoint=False):
        x,y=7.2+2.3*np.cos(ang),4.1+2.0*np.sin(ang)
        ax.add_patch(FancyArrowPatch((7.2,4.1),(x,y),arrowstyle="-",color=PURPLE,lw=1,alpha=0.4,zorder=2))
        ax.add_patch(Circle((x,y),0.32,fc="white",ec=PURPLE,lw=1.4,zorder=3))
    fig.savefig(ROOT/"figures/cover.png",dpi=200,facecolor=fig.get_facecolor())
    print("cover.png")
if __name__=="__main__": main()

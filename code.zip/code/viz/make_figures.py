"""Figures for the Paper2Agent article, on the shared light theme."""
import json, sys, pathlib
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa

R = ROOT / "results"
AIC = GOOD
BADC = AGGRESSIVE
BLUE = RESTRAINED
PURPLE = MIXED
GOLD = PASSIVE


def save2(fig, name):
    out = ROOT / "figures" / name
    fig.savefig(out, facecolor=fig.get_facecolor()); plt.close(fig)
    return out


def fig_pipeline():
    """The 6-step Paper2Agent pipeline."""
    fig, gs = card(9.4, 4.2,
                   "How a dead PDF becomes a living agent",
                   "Paper2Agent runs six steps automatically, turning a paper's code and data into tools an AI "
                   "can call in plain English.",
                   "Source: Miao et al., Nature (2026). Diagram by the author.",
                   top=0.80, bottom=0.10, left=0.04, right=0.96)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 3); ax.axis("off")
    steps = [("Find the code", BLUE), ("Set up environment", BLUE),
             ("Discover tutorials", GOLD), ("Run them", GOLD),
             ("Extract tools", AIC), ("Assemble agent", PURPLE)]
    w = 1.75
    for i, (label, col) in enumerate(steps):
        x = 0.4 + i * 1.92
        ax.add_patch(FancyBboxPatch((x, 1.1), w, 0.9, boxstyle="round,pad=0,rounding_size=0.08",
                                    fc=col, alpha=0.14, ec=col, lw=1.4, zorder=3))
        ax.text(x + w/2, 1.72, f"{i+1}", ha="center", fontsize=10, fontweight="bold", color=col, zorder=4)
        ax.text(x + w/2, 1.38, label, ha="center", fontsize=8.1, color=INK, zorder=4)
        if i < 5:
            ax.add_patch(FancyArrowPatch((x + w, 1.55), (x + 1.92, 1.55), arrowstyle="-|>",
                                         mutation_scale=10, color=FAINT, lw=1.3, zorder=2))
    ax.text(0.4, 2.5, "static paper + code", fontsize=9, color=SUB, style="italic")
    ax.text(11.6, 2.5, "living agent", fontsize=9, color=PURPLE, style="italic", ha="right", fontweight="semibold")
    ax.text(6, 0.5, "The agents test their own tools: 593 of 599 passed automated validation.",
            ha="center", fontsize=8.6, color=SUB)
    return save2(fig, "pipeline.png")


def fig_accuracy():
    j = json.load(open(R / "repro.json"))["real"]
    fig, gs = card(9.2, 4.8,
                   "The paper-agents beat a strong AI given the same code",
                   "Accuracy answering questions about a paper: a paper-agent versus a top chatbot handed the "
                   "paper's raw repository.",
                   "Source: Miao et al., Nature (2026). Chart by the author from reported results.",
                   top=0.72, bottom=0.13, left=0.10, right=0.75)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]), "", "Accuracy")
    ax.grid(axis="x", visible=False)
    groups = ["Across 100 papers", "AlphaGenome agent"]
    agent = [j["accuracy"], j["alphagenome_acc"]]
    base = [j["baseline"], j["alphagenome_baseline"]]
    x = np.arange(len(groups))
    ax.bar(x - 0.2, agent, width=0.38, color=AIC, zorder=3, label="Paper2Agent")
    ax.bar(x + 0.2, base, width=0.38, color=NEUTRAL if (NEUTRAL:="#9AA6B6") else BADC, zorder=3,
           label="Chatbot + raw repo")
    for xi, a, b in zip(x, agent, base):
        ax.text(xi - 0.2, a + 1.5, f"{a:.1f}%", ha="center", fontsize=10, fontweight="semibold", color=INK)
        ax.text(xi + 0.2, b + 1.5, f"{b:.1f}%", ha="center", fontsize=10, color=SUB)
    ax.set_xticks(x, groups); ax.tick_params(axis="x", labelsize=10, labelcolor=INK)
    ax.set_ylim(0, 108); ax.set_yticks([0, 25, 50, 75, 100], ["0", "25%", "50%", "75%", "100%"])
    ax.legend(loc="upper right", fontsize=9, framealpha=0.9)
    return save2(fig, "accuracy.png")


def fig_repro():
    j = json.load(open(R / "repro.json"))
    e1 = j["e1"]
    fig, gs = card(9.2, 4.8,
                   "Why it's really a reproducibility test in disguise",
                   "To become an agent, a paper's code must actually run. So the conversion rate measures "
                   "something science badly needs: reproducibility.",
                   "Source: conversion model by the author, anchored to reproducibility studies; real overall "
                   "rate from Miao et al. (2026).",
                   top=0.75, bottom=0.14, left=0.26, right=0.93)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Share of papers that could be turned into a working agent", "")
    ax.grid(axis="y", visible=False); ax.grid(axis="x", visible=True)
    rows = [("Shares nothing", e1["nothing"], BADC),
            ("Shares data only", e1["data_only"], GOLD),
            ("Shares code + data", e1["code_data"], AIC),
            ("Real study (bioRxiv)", 0.74, PURPLE)]
    y = np.arange(len(rows))[::-1]
    for yy, (label, val, col) in zip(y, rows):
        ax.barh(yy, val * 100, height=0.6, color=col, zorder=3)
        ax.text(val * 100 + 2, yy, f"{val*100:.0f}%", va="center", fontsize=10.5,
                fontweight="semibold", color=INK)
    ax.set_yticks(y, [r[0] for r in rows]); ax.tick_params(axis="y", labelsize=9.8, labelcolor=INK)
    ax.set_xlim(0, 100); ax.set_xticks([0, 25, 50, 75, 100], ["0", "25%", "50%", "75%", "100%"])
    return save2(fig, "repro.png")


def fig_network():
    j = json.load(open(R / "repro.json"))["e2"]
    n = np.array(j["n"]); conn = np.array(j["connections"]); novel = np.array(j["novel"])
    fig, gs = card(9.2, 4.8,
                   "The real payoff grows faster than the number of papers",
                   "Every new paper-agent can connect to every existing one. Possible collaborations grow with "
                   "the square of the agents.",
                   "Source: network model by the author. One real cross-paper link (ADHD / MPHOSPH9) has already "
                   "been reported.",
                   top=0.75, bottom=0.14, left=0.10, right=0.80)
    ax = style_ax(fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0]),
                  "Number of paper-agents", "Possible cross-paper connections")
    ax.plot(n, conn, color=PURPLE, lw=2.8)
    ax.fill_between(n, 0, conn, color=PURPLE, alpha=0.08)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.scatter([100], [conn[np.argmin(np.abs(n-100))]], s=60, color=AIC, zorder=5,
               edgecolors=CARD, linewidths=1.5)
    ax.annotate("100 agents today", xy=(100, conn[np.argmin(np.abs(n-100))]),
                xytext=(11, 350), fontsize=9, color=AIC, fontweight="semibold",
                arrowprops=dict(arrowstyle="-|>", color=AIC, lw=1.2))
    ax.annotate("millions of papers\nout there", xy=(n[-1], conn[-1]), xytext=(220, conn[-1]*0.15),
                fontsize=9, color=PURPLE, fontweight="semibold",
                arrowprops=dict(arrowstyle="-|>", color=PURPLE, lw=1.2))
    ax.set_xlim(10, 1000)
    return save2(fig, "network.png")


def fig_discovery():
    """How two paper-agents found a new link."""
    fig, gs = card(9.2, 4.4,
                   "Two papers that never cited each other, introduced by their agents",
                   "A genome-prediction agent met an ADHD-genetics agent, and together they surfaced a link no "
                   "human had reported.",
                   "Source: Miao et al., Nature (2026). Diagram by the author.",
                   top=0.80, bottom=0.08, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 4); ax.axis("off")
    ax.add_patch(FancyBboxPatch((0.5, 1.6), 3.0, 1.2, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=BLUE, alpha=0.14, ec=BLUE, lw=1.4))
    ax.text(2.0, 2.45, "Genome-prediction\nagent", ha="center", va="center", fontsize=9,
            fontweight="semibold", color=INK, linespacing=1.2)
    ax.text(2.0, 1.85, "predicts mutation effects", ha="center", fontsize=7.4, color=SUB)
    ax.add_patch(FancyBboxPatch((8.5, 1.6), 3.0, 1.2, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=GOLD, alpha=0.16, ec=GOLD, lw=1.4))
    ax.text(10.0, 2.45, "ADHD-genetics\nagent", ha="center", va="center", fontsize=9,
            fontweight="semibold", color=INK, linespacing=1.2)
    ax.text(10.0, 1.85, "risk-gene dataset", ha="center", fontsize=7.4, color=SUB)
    ax.add_patch(FancyArrowPatch((3.5, 2.2), (8.5, 2.2), arrowstyle="<|-|>", mutation_scale=14,
                                 color=PURPLE, lw=2))
    ax.add_patch(FancyBboxPatch((4.3, 2.55), 3.4, 0.5, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=PURPLE, ec="white", lw=1, zorder=4))
    ax.text(6.0, 2.8, "apply method to data", ha="center", va="center", fontsize=8,
            color="white", fontweight="semibold", zorder=5)
    ax.add_patch(FancyBboxPatch((3.6, 0.3), 4.8, 0.85, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=AIC, alpha=0.14, ec=AIC, lw=1.4))
    ax.text(6.0, 0.72, "New finding: a variant near MPHOSPH9\nlinked to ADHD risk, never reported before",
            ha="center", va="center", fontsize=8.3, color="#14795A", fontweight="semibold", linespacing=1.2)
    ax.add_patch(FancyArrowPatch((6.0, 2.1), (6.0, 1.2), arrowstyle="-|>", mutation_scale=12,
                                 color=FAINT, lw=1.4))
    return save2(fig, "discovery.png")


if __name__ == "__main__":
    for f in [fig_pipeline, fig_accuracy, fig_repro, fig_network, fig_discovery]:
        print(f())


def fig_old_vs_new():
    """Reading a paper the old way vs the agent way."""
    fig, gs = card(9.2, 4.6,
                   "Two ways to use a paper's method",
                   "The old way is an archaeology project. The agent way is a sentence.",
                   "Original diagram by the author.",
                   top=0.80, bottom=0.10, left=0.05, right=0.95)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 5); ax.axis("off")
    # old way
    ax.text(0.3, 4.4, "The old way", fontsize=11, fontweight="semibold", color=BADC)
    old = ["find the GitHub repo", "install old dependencies", "fix broken versions",
           "decode the methods section", "finally run it (maybe)"]
    for i, t in enumerate(old):
        y = 3.7 - i*0.62
        ax.add_patch(FancyBboxPatch((0.4, y-0.22), 5.0, 0.44, boxstyle="round,pad=0,rounding_size=0.06",
                                    fc=BADC, alpha=0.07, ec=BADC, lw=1, zorder=3))
        ax.text(0.65, y, f"{i+1}.  {t}", va="center", fontsize=8.6, color=INK)
    ax.text(2.9, 0.4, "days of work", ha="center", fontsize=9, color=BADC, fontweight="semibold", style="italic")
    # new way
    ax.text(6.6, 4.4, "The agent way", fontsize=11, fontweight="semibold", color=AIC)
    ax.add_patch(FancyBboxPatch((6.5, 2.3), 5.1, 1.3, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=AIC, alpha=0.1, ec=AIC, lw=1.4, zorder=3))
    ax.text(9.05, 2.95, '"apply your method\nto my dataset"', ha="center", va="center",
            fontsize=11, color=INK, fontweight="semibold", linespacing=1.3)
    ax.add_patch(FancyArrowPatch((9.05, 2.25), (9.05, 1.6), arrowstyle="-|>", mutation_scale=13,
                                 color=FAINT, lw=1.4))
    ax.add_patch(FancyBboxPatch((7.3, 0.9), 3.5, 0.6, boxstyle="round,pad=0,rounding_size=0.08",
                                fc=PURPLE, alpha=0.9, ec="white", lw=1, zorder=3))
    ax.text(9.05, 1.2, "done, correctly", ha="center", va="center", fontsize=9,
            color="white", fontweight="semibold")
    ax.text(9.05, 0.4, "one sentence", ha="center", fontsize=9, color=AIC, fontweight="semibold", style="italic")
    ax.plot([6.1, 6.1], [0.3, 4.2], color=RULE, lw=1, ls=(0, (3, 3)))
    return save2(fig, "old_vs_new.png")


def fig_knowledge_evolution():
    """The evolution of how we store knowledge."""
    fig, gs = card(9.2, 4.0,
                   "360 years of frozen knowledge, about to thaw",
                   "Every era stored knowledge as something passive to be read. Paper2Agent proposes the first "
                   "active form.",
                   "Original diagram by the author.",
                   top=0.80, bottom=0.12, left=0.06, right=0.94)
    ax = fig.add_subplot(GridSpec(1, 1, figure=fig, **gs)[0])
    ax.set_xlim(0, 12); ax.set_ylim(0, 4); ax.axis("off")
    stages = [("Stone\ntablets", "carved", "#B0A89A"),
              ("Printed\npages", "typed", "#A6B0BE"),
              ("PDFs", "uploaded", BLUE),
              ("Paper\nagents", "executed", PURPLE)]
    xs = [1.6, 4.4, 7.2, 10.0]
    for i, ((label, verb, col), x) in enumerate(zip(stages, xs)):
        active = (i == 3)
        ax.add_patch(Circle((x, 2.4), 0.6, fc=col, alpha=0.9 if active else 0.5,
                            ec="white", lw=2, zorder=4))
        ax.text(x, 2.4, label, ha="center", va="center", fontsize=8.2,
                color="white" if active else INK, fontweight="semibold", zorder=5, linespacing=1.0)
        ax.text(x, 1.4, verb, ha="center", fontsize=8, color=col if active else SUB,
                fontweight="semibold" if active else "normal")
        ax.text(x, 3.4, "passive" if not active else "ACTIVE", ha="center", fontsize=7.8,
                color=SUB if not active else PURPLE, fontweight="bold" if active else "normal")
        if i < 3:
            ax.add_patch(FancyArrowPatch((x+0.6, 2.4), (xs[i+1]-0.6, 2.4), arrowstyle="-|>",
                                         mutation_scale=12, color=FAINT, lw=1.3, zorder=2))
    ax.text(10.0, 0.5, "it can act on its own knowledge", ha="center", fontsize=8,
            color=PURPLE, style="italic")
    return save2(fig, "knowledge_evolution.png")

"""Animated: a static PDF transforming into a living, callable agent."""
import sys, pathlib
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation, PillowWriter
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from viz.style import *  # noqa
AIC=GOOD; BLUE=RESTRAINED; PURPLE=MIXED; GOLD=PASSIVE

def main():
    fig=plt.figure(figsize=(8.2,4.8),facecolor=BG,dpi=100)
    fig.text(0.06,0.93,"From a paper you read to an agent you talk to",fontsize=15,fontweight="semibold",color=INK)
    fig.text(0.06,0.875,"Paper2Agent reads the paper, re-runs its code, and wraps the working methods as callable tools.",fontsize=9.2,color=SUB)
    fig.text(0.06,0.05,"Illustration by the author, from Miao et al., Nature (2026).",fontsize=8,color=FAINT)
    ax=fig.add_axes([0.04,0.12,0.92,0.72]); ax.set_xlim(0,12); ax.set_ylim(0,6); ax.axis("off")

    # left: the PDF (static lines of text)
    pdf=FancyBboxPatch((0.6,1.6),2.4,3.0,boxstyle="round,pad=0,rounding_size=0.06",fc="white",ec=RULE,lw=1.4,zorder=3)
    ax.add_patch(pdf)
    lines=[]
    for i in range(9):
        ln=ax.plot([1.0,2.6],[4.2-i*0.32,4.2-i*0.32],color="#C8D0DB",lw=2,solid_capstyle="round",zorder=4)[0]
        lines.append(ln)
    ax.text(1.8,1.3,"static PDF",ha="center",fontsize=8.5,color=SUB)

    # middle: worker agents
    workers=[]
    for k in range(6):
        c=Circle((4.9+(k%3)*0.5,3.6-(k//3)*0.6),0.14,fc=GOLD,ec="white",lw=1,alpha=0,zorder=5)
        ax.add_patch(c); workers.append(c)
    wtext=ax.text(5.4,1.9,"",ha="center",fontsize=8,color=GOLD,fontweight="semibold")

    # right: the agent with tools
    agent=FancyBboxPatch((8.6,1.9),2.8,2.4,boxstyle="round,pad=0,rounding_size=0.1",fc=PURPLE,alpha=0,ec=PURPLE,lw=1.6,zorder=3)
    ax.add_patch(agent)
    atext=ax.text(10.0,3.5,"",ha="center",va="center",fontsize=10,color="white",fontweight="semibold",zorder=5)
    tools=[]
    for k in range(3):
        t=FancyBboxPatch((9.0+k*0.85,2.1),0.7,0.45,boxstyle="round,pad=0,rounding_size=0.08",fc="white",ec=PURPLE,lw=1,alpha=0,zorder=5)
        ax.add_patch(t); tools.append(t)
    chat=ax.text(10.0,1.4,"",ha="center",fontsize=8,color=PURPLE,fontweight="semibold")

    arrow1=FancyArrowPatch((3.1,3.1),(4.6,3.1),arrowstyle="-|>",mutation_scale=12,color=FAINT,lw=1.4,alpha=0)
    arrow2=FancyArrowPatch((6.5,3.1),(8.5,3.1),arrowstyle="-|>",mutation_scale=12,color=FAINT,lw=1.4,alpha=0)
    ax.add_patch(arrow1); ax.add_patch(arrow2)

    frames=40
    def update(f):
        # phase 1 (0-10): workers appear and "read"
        if f>=3:
            arrow1.set_alpha(min(1,(f-3)/4))
            for k,c in enumerate(workers):
                c.set_alpha(min(1,max(0,(f-4-k)/3)))
            wtext.set_text("agents re-run the code" if f>6 else "")
        # phase 2 (14-26): agent assembles
        if f>=16:
            arrow2.set_alpha(min(1,(f-16)/4))
            agent.set_alpha(min(0.9,(f-16)/6))
            atext.set_text("Paper\nagent" if f>18 else "")
            for k,t in enumerate(tools):
                t.set_alpha(min(1,max(0,(f-18-k*2)/3)))
        # phase 3 (30+): it answers
        if f>=30:
            chat.set_text('"apply your method to my data" ->')
        return []
    anim=FuncAnimation(fig,update,frames=frames,blit=False)
    out=ROOT/"figures/anim_transform.gif"
    anim.save(out,writer=PillowWriter(fps=10),savefig_kwargs={"facecolor":BG})
    print(out)

if __name__=="__main__":
    main()
